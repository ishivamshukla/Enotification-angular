import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { UserAlertComponent } from './user-alert/user-alert.component';
import { AppRoutingModule } from '../app-routing.module';
import { AnnouncementComponent } from './announcement/announcement.component';
import { NoticeboardComponent } from './noticeboard/noticeboard.component';
import { ServiceComponent } from './service/service.component';



@NgModule({
  declarations: [NavbarComponent, FooterComponent,NoticeboardComponent,AnnouncementComponent, UserAlertComponent, AnnouncementComponent, ServiceComponent],
  imports: [
    AppRoutingModule,
    CommonModule
  ],
  exports:[NavbarComponent, FooterComponent,NoticeboardComponent,AnnouncementComponent, UserAlertComponent, AnnouncementComponent,ServiceComponent]
})
export class SharedModule { }
