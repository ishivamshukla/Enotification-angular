import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-alert',
  templateUrl: './user-alert.component.html',
  styleUrls: ['./user-alert.component.css']
})
export class UserAlertComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
