import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExaminationDetailsComponent } from './examination-details/examination-details.component';
import { ExaminationComponent } from './examination/examination.component';
import { ExaminationRoutingModule } from './examination-routing.module';


@NgModule({
  declarations: [ExaminationComponent,ExaminationDetailsComponent],
  imports: [
    ExaminationRoutingModule,
    CommonModule
  ],
  exports:[ExaminationComponent,ExaminationDetailsComponent]
})
export class ExaminationModule { }
