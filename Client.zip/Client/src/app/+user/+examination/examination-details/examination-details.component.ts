import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examination-details',
  templateUrl: './examination-details.component.html',
  styleUrls: ['./examination-details.component.css']
})
export class ExaminationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
