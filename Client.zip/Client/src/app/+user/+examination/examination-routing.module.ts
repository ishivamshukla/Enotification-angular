
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ExaminationDetailsComponent } from './examination-details/examination-details.component';
import { ExaminationComponent } from './examination/examination.component';


const routes: Routes = [
   { path: '', component: ExaminationComponent },
   { path: 'examination-details:id', component: ExaminationDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class ExaminationRoutingModule { }
