import { SyllabusComponent } from './syllabus/syllabus.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SyllabusRoutingModule } from './syllabus-routing.module';

@NgModule({
  declarations: [SyllabusComponent],
  imports: [
    SyllabusRoutingModule,
    CommonModule
  ],
  exports:[SyllabusComponent]
})
export class SyllabusModule { }
