import { ResultsComponent } from './results/results.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResultsRoutingModule } from './results-routing.module';

@NgModule({
  declarations: [ResultsComponent],
  imports: [
    ResultsRoutingModule,
    CommonModule
  ],
  exports:[ResultsComponent]
})
export class ResultsModule { }
