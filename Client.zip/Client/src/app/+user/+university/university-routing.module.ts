
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UniversityComponent } from './university/university.component';
import { StateComponent } from './state/state.component';
import { UniversityDetailsComponent } from './university-details/university-details.component';


const routes: Routes = [
   { path: '', component: StateComponent },
   { path: 'university:id', component: UniversityComponent },
   { path: 'university-details:id', component: UniversityDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UniversityRoutingModule { }
