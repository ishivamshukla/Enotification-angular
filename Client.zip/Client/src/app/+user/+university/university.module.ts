import { UniversityComponent } from './university/university.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StateComponent } from './state/state.component';
import { UniversityDetailsComponent } from './university-details/university-details.component';
import { UniversityRoutingModule } from './university-routing.module';

@NgModule({
  declarations: [StateComponent,UniversityComponent, UniversityDetailsComponent],
  imports: [
    UniversityRoutingModule,
    CommonModule
  ],
  exports:[StateComponent,UniversityComponent, UniversityDetailsComponent]
})
export class UniversityModule { }
