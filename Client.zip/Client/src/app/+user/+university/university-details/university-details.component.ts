import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-university-details',
  templateUrl: './university-details.component.html',
  styleUrls: ['./university-details.component.css']
})
export class UniversityDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
