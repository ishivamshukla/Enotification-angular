import { AboutUsComponent } from './+user/about-us/about-us.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './+user/home/home.component';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'results', loadChildren: () => import('./+user/+results/results.module').then(m => m.ResultsModule) } ,
  { path: 'syllabus', loadChildren: () => import('./+user/+syllabus/syllabus.module').then(m => m.SyllabusModule) }, 
  { path: 'examination', loadChildren: () => import('./+user/+examination/examination.module').then(m => m.ExaminationModule) } ,
   { path: 'state', loadChildren: () => import('./+user/+university/university.module').then(m => m.UniversityModule) } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
